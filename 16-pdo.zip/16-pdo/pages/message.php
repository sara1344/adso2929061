<section class="message">
    <?=$_SESSION['message']?>
</section>