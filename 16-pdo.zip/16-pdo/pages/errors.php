<section class="error">
    <?=$_SESSION['error']?>
</section>